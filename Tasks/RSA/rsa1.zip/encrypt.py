from Crypto.Util.number import bytes_to_long, GCD, inverse
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5

def import_key(p_path, q_path, e = 65537):
	p = int(open(p_path).read(), 10)
	q = int(open(q_path).read(), 10)
	n = p*q
	phin = (p-1)*(q-1)
	d = inverse(e, phin)
	key = RSA.construct((n, e, d, p, q))
	return key

flag = open('flag.txt', 'rb').read()


key = import_key('p', 'q')

enckey = PKCS1_v1_5.new(key)
enc_flag = enckey.encrypt(flag)

open("key.pub", "wb").write(key.publickey().exportKey(format="PEM"))
open("flag.txt.enc", "wb").write(enc_flag)
